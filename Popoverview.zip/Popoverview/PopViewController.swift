//
//  PopViewController.swift
//  Popoverview
//
//  Created by Admin on 8/29/16.
//  Copyright © 2016 nguyenhao. All rights reserved.
//

import UIKit
class PopViewController : UIViewController{
override func viewDidLoad() {
    super.viewDidLoad()
   
    
    
    
}
    
    
}